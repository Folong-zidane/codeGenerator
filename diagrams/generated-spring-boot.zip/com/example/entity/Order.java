// Generated Enhanced Entity with ORM mapping and Swagger documentation
package com.example.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.lang.Float;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(
    name = "order"
)
@Schema(
    description = "Order entity"
)
public class Order {
  @Id
  @GeneratedValue
  @Column(
      name = "id",
      updatable = false
  )
  private UUID id;

  @Column(
      name = "id",
      nullable = true
  )
  @Schema(
      description = "id (UUID)",
      required = false
  )
  private UUID id;

  @Column(
      name = "total_amount",
      nullable = true
  )
  @Schema(
      description = "totalAmount (Float)",
      required = false
  )
  private Float totalAmount;

  @Column(
      name = "status",
      nullable = true,
      length = 255
  )
  @Schema(
      description = "status (String)",
      required = false
  )
  private String status;

  @Column(
      name = "created_at",
      nullable = false,
      updatable = false
  )
  private Instant createdAt;

  @Column(
      name = "updated_at",
      nullable = false
  )
  private Instant updatedAt;

  @Version
  private Long version;

  public Order() {
    // Default constructor for JPA
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public Float getTotalAmount() {
    return totalAmount;
  }

  public void setTotalAmount(Float totalAmount) {
    this.totalAmount = totalAmount;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    Order other = (Order) obj;
    return id != null && id.equals(other.id);
  }

  @Override
  public int hashCode() {
    return id != null ? id.hashCode() : 0;
  }
}
