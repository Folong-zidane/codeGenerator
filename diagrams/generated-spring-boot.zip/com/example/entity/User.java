// Generated Enhanced Entity with ORM mapping and Swagger documentation
package com.example.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import jakarta.validation.constraints.Email;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(
    name = "user"
)
@Schema(
    description = "User entity"
)
public class User {
  @Id
  @GeneratedValue
  @Column(
      name = "id",
      updatable = false
  )
  private UUID id;

  @Column(
      name = "id",
      nullable = true
  )
  @Schema(
      description = "id (UUID)",
      required = false
  )
  private UUID id;

  @Column(
      name = "username",
      nullable = true,
      length = 255
  )
  @Schema(
      description = "Name",
      required = false
  )
  private String username;

  @Email(
      message = "Invalid email format"
  )
  @Column(
      name = "email",
      nullable = true,
      length = 255,
      unique = true
  )
  @Schema(
      description = "Email address",
      required = false
  )
  private String email;

  @Column(
      name = "created_at",
      nullable = false,
      updatable = false
  )
  private Instant createdAt;

  @Column(
      name = "updated_at",
      nullable = false
  )
  private Instant updatedAt;

  @Version
  private Long version;

  public User() {
    // Default constructor for JPA
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    User other = (User) obj;
    return id != null && id.equals(other.id);
  }

  @Override
  public int hashCode() {
    return id != null ? id.hashCode() : 0;
  }
}
