#!/bin/bash
echo "🚀 Démarrage Django..."
python3 -m venv venv 2>/dev/null || true
source venv/bin/activate
pip install -r requirements.txt -q
python manage.py migrate
python manage.py runserver
