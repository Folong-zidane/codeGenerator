# Database migration for ecommerce_complex
from alembic import op
import sqlalchemy as sa

def upgrade():
    # Create Entity table
    op.create_table('entitys',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('createdAt', sa.String(255)),
        sa.Column('updatedAt', sa.String(255)),
        sa.Column('Long', sa.String(255)),
        sa.Column('LocalDateTime', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create User table
    op.create_table('users',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('username', sa.String(255)),
        sa.Column('email', sa.String(255)),
        sa.Column('passwordHash', sa.String(255)),
        sa.Column('role', sa.String(255)),
        sa.Column('lastLogin', sa.String(255)),
        sa.Column('active', sa.Boolean()),
        sa.Column('boolean', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('List~Order~', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create Order table
    op.create_table('orders',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('orderNumber', sa.String(255)),
        sa.Column('status', sa.String(255)),
        sa.Column('orderDate', sa.String(255)),
        sa.Column('totalAmount', sa.String(255)),
        sa.Column('shippingAddress', sa.String(255)),
        sa.Column('BigDecimal', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('List~OrderItem~', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create Product table
    op.create_table('products',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('name', sa.String(255)),
        sa.Column('description', sa.String(255)),
        sa.Column('price', sa.String(255)),
        sa.Column('quantity', sa.Integer()),
        sa.Column('sku', sa.String(255)),
        sa.Column('category', sa.String(255)),
        sa.Column('reviews', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('Double', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create OrderItem table
    op.create_table('orderitems',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('quantity', sa.Integer()),
        sa.Column('unitPrice', sa.String(255)),
        sa.Column('lineTotal', sa.String(255)),
        sa.Column('BigDecimal', sa.String(255)),
        sa.Column('Product', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create Review table
    op.create_table('reviews',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('rating', sa.Integer()),
        sa.Column('comment', sa.String(255)),
        sa.Column('author', sa.String(255)),
        sa.Column('helpfulCount', sa.Integer()),
        sa.Column('int', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create Payment table
    op.create_table('payments',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('boolean', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('PaymentStatus', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create CreditCardPayment table
    op.create_table('creditcardpayments',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('cardNumber', sa.String(255)),
        sa.Column('expiryDate', sa.String(255)),
        sa.Column('cvv', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create PayPalPayment table
    op.create_table('paypalpayments',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('email', sa.String(255)),
        sa.Column('transactionId', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('boolean', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

    # Create Inventory table
    op.create_table('inventorys',
        sa.Column('id', sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column('Product~ products', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('void', sa.String(255)),
        sa.Column('Product', sa.String(255)),
        sa.Column('quantity) void', sa.String(255)),
        sa.Column('status', sa.String(50), default='ACTIVE'),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now())
    )

def downgrade():
    op.drop_table('entitys')
    op.drop_table('users')
    op.drop_table('orders')
    op.drop_table('products')
    op.drop_table('orderitems')
    op.drop_table('reviews')
    op.drop_table('payments')
    op.drop_table('creditcardpayments')
    op.drop_table('paypalpayments')
    op.drop_table('inventorys')
