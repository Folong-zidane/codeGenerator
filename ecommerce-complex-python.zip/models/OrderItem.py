from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class OrderItemStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class OrderItem(Base):
    __tablename__ = 'orderitems'

    quantity = Column(Integer)
    unitPrice = Column(String)
    lineTotal = Column(String)
    BigDecimal = Column(String)
    Product = Column(String)
    status = Column(Enum(OrderItemStatus), default=OrderItemStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != OrderItemStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = OrderItemStatus.SUSPENDED

    def activate(self):
        if self.status != OrderItemStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = OrderItemStatus.ACTIVE
