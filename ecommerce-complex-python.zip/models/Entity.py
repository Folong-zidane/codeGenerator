from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class EntityStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class Entity(Base):
    __tablename__ = 'entitys'

    id = Column(Integer, primary_key=True, autoincrement=True)
    createdAt = Column(String)
    updatedAt = Column(String)
    Long = Column(String)
    LocalDateTime = Column(String)
    status = Column(Enum(EntityStatus), default=EntityStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != EntityStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = EntityStatus.SUSPENDED

    def activate(self):
        if self.status != EntityStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = EntityStatus.ACTIVE
