from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class PaymentStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class Payment(Base):
    __tablename__ = 'payments'

    boolean = Column(String)
    boolean = Column(String)
    PaymentStatus = Column(String)
    status = Column(Enum(PaymentStatus), default=PaymentStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != PaymentStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = PaymentStatus.SUSPENDED

    def activate(self):
        if self.status != PaymentStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = PaymentStatus.ACTIVE
