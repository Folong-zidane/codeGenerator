from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class CreditCardPaymentStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class CreditCardPayment(Base):
    __tablename__ = 'creditcardpayments'

    cardNumber = Column(String)
    expiryDate = Column(String)
    cvv = Column(String)
    boolean = Column(String)
    boolean = Column(String)
    status = Column(Enum(CreditCardPaymentStatus), default=CreditCardPaymentStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != CreditCardPaymentStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = CreditCardPaymentStatus.SUSPENDED

    def activate(self):
        if self.status != CreditCardPaymentStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = CreditCardPaymentStatus.ACTIVE
