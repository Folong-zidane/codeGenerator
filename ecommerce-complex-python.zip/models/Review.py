from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class ReviewStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class Review(Base):
    __tablename__ = 'reviews'

    rating = Column(Integer)
    comment = Column(String)
    author = Column(String)
    helpfulCount = Column(Integer)
    int = Column(String)
    boolean = Column(String)
    status = Column(Enum(ReviewStatus), default=ReviewStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != ReviewStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = ReviewStatus.SUSPENDED

    def activate(self):
        if self.status != ReviewStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = ReviewStatus.ACTIVE
