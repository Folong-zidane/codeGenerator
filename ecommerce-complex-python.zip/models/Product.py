from sqlalchemy import Column, Integer, String, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum as PyEnum

class ProductStatus(PyEnum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"

Base = declarative_base()

class Product(Base):
    __tablename__ = 'products'

    name = Column(String)
    description = Column(String)
    price = Column(String)
    quantity = Column(Integer)
    sku = Column(String)
    category = Column(String)
    reviews = Column(String)
    void = Column(String)
    void = Column(String)
    Double = Column(String)
    boolean = Column(String)
    status = Column(Enum(ProductStatus), default=ProductStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def suspend(self):
        if self.status != ProductStatus.ACTIVE:
            raise ValueError(f'Cannot suspend user in state: {self.status}')
        self.status = ProductStatus.SUSPENDED

    def activate(self):
        if self.status != ProductStatus.SUSPENDED:
            raise ValueError(f'Cannot activate user in state: {self.status}')
        self.status = ProductStatus.ACTIVE
