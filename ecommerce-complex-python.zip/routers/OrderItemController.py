from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.orderitem import OrderItem
from services.orderitem_service import OrderItemService
from database import get_db

router = APIRouter(prefix='/api/orderitems', tags=['orderitems'])

@router.get('/', response_model=List[OrderItem])
def get_all_orderitems(db: Session = Depends(get_db)):
    service = OrderItemService(db)
    return service.get_all()

@router.get('/{id}', response_model=OrderItem)
def get_orderitem(id: int, db: Session = Depends(get_db)):
    service = OrderItemService(db)
    entity = service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail='OrderItem not found')
    return entity

@router.post('/', response_model=OrderItem, status_code=201)
def create_orderitem(entity: OrderItem, db: Session = Depends(get_db)):
    service = OrderItemService(db)
    return service.create(entity)

@router.delete('/{id}', status_code=204)
def delete_orderitem(id: int, db: Session = Depends(get_db)):
    service = OrderItemService(db)
    if not service.delete(id):
        raise HTTPException(status_code=404, detail='OrderItem not found')

@router.patch('/{id}/suspend', response_model=OrderItem)
def suspend_orderitem(id: int, db: Session = Depends(get_db)):
    service = OrderItemService(db)
    try:
        return service.suspend_orderitem(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.patch('/{id}/activate', response_model=OrderItem)
def activate_orderitem(id: int, db: Session = Depends(get_db)):
    service = OrderItemService(db)
    try:
        return service.activate_orderitem(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
