from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.paypalpayment import PayPalPayment
from services.paypalpayment_service import PayPalPaymentService
from database import get_db

router = APIRouter(prefix='/api/paypalpayments', tags=['paypalpayments'])

@router.get('/', response_model=List[PayPalPayment])
def get_all_paypalpayments(db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    return service.get_all()

@router.get('/{id}', response_model=PayPalPayment)
def get_paypalpayment(id: int, db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    entity = service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail='PayPalPayment not found')
    return entity

@router.post('/', response_model=PayPalPayment, status_code=201)
def create_paypalpayment(entity: PayPalPayment, db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    return service.create(entity)

@router.delete('/{id}', status_code=204)
def delete_paypalpayment(id: int, db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    if not service.delete(id):
        raise HTTPException(status_code=404, detail='PayPalPayment not found')

@router.patch('/{id}/suspend', response_model=PayPalPayment)
def suspend_paypalpayment(id: int, db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    try:
        return service.suspend_paypalpayment(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.patch('/{id}/activate', response_model=PayPalPayment)
def activate_paypalpayment(id: int, db: Session = Depends(get_db)):
    service = PayPalPaymentService(db)
    try:
        return service.activate_paypalpayment(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
