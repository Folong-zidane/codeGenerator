from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.inventory import Inventory
from services.inventory_service import InventoryService
from database import get_db

router = APIRouter(prefix='/api/inventorys', tags=['inventorys'])

@router.get('/', response_model=List[Inventory])
def get_all_inventorys(db: Session = Depends(get_db)):
    service = InventoryService(db)
    return service.get_all()

@router.get('/{id}', response_model=Inventory)
def get_inventory(id: int, db: Session = Depends(get_db)):
    service = InventoryService(db)
    entity = service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail='Inventory not found')
    return entity

@router.post('/', response_model=Inventory, status_code=201)
def create_inventory(entity: Inventory, db: Session = Depends(get_db)):
    service = InventoryService(db)
    return service.create(entity)

@router.delete('/{id}', status_code=204)
def delete_inventory(id: int, db: Session = Depends(get_db)):
    service = InventoryService(db)
    if not service.delete(id):
        raise HTTPException(status_code=404, detail='Inventory not found')

@router.patch('/{id}/suspend', response_model=Inventory)
def suspend_inventory(id: int, db: Session = Depends(get_db)):
    service = InventoryService(db)
    try:
        return service.suspend_inventory(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.patch('/{id}/activate', response_model=Inventory)
def activate_inventory(id: int, db: Session = Depends(get_db)):
    service = InventoryService(db)
    try:
        return service.activate_inventory(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
