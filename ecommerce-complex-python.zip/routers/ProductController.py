from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.product import Product
from services.product_service import ProductService
from database import get_db

router = APIRouter(prefix='/api/products', tags=['products'])

@router.get('/', response_model=List[Product])
def get_all_products(db: Session = Depends(get_db)):
    service = ProductService(db)
    return service.get_all()

@router.get('/{id}', response_model=Product)
def get_product(id: int, db: Session = Depends(get_db)):
    service = ProductService(db)
    entity = service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail='Product not found')
    return entity

@router.post('/', response_model=Product, status_code=201)
def create_product(entity: Product, db: Session = Depends(get_db)):
    service = ProductService(db)
    return service.create(entity)

@router.delete('/{id}', status_code=204)
def delete_product(id: int, db: Session = Depends(get_db)):
    service = ProductService(db)
    if not service.delete(id):
        raise HTTPException(status_code=404, detail='Product not found')

@router.patch('/{id}/suspend', response_model=Product)
def suspend_product(id: int, db: Session = Depends(get_db)):
    service = ProductService(db)
    try:
        return service.suspend_product(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.patch('/{id}/activate', response_model=Product)
def activate_product(id: int, db: Session = Depends(get_db)):
    service = ProductService(db)
    try:
        return service.activate_product(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
