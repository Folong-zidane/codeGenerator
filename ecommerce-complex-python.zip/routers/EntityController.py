from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.entity import Entity
from services.entity_service import EntityService
from database import get_db

router = APIRouter(prefix='/api/entitys', tags=['entitys'])

@router.get('/', response_model=List[Entity])
def get_all_entitys(db: Session = Depends(get_db)):
    service = EntityService(db)
    return service.get_all()

@router.get('/{id}', response_model=Entity)
def get_entity(id: int, db: Session = Depends(get_db)):
    service = EntityService(db)
    entity = service.get_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail='Entity not found')
    return entity

@router.post('/', response_model=Entity, status_code=201)
def create_entity(entity: Entity, db: Session = Depends(get_db)):
    service = EntityService(db)
    return service.create(entity)

@router.delete('/{id}', status_code=204)
def delete_entity(id: int, db: Session = Depends(get_db)):
    service = EntityService(db)
    if not service.delete(id):
        raise HTTPException(status_code=404, detail='Entity not found')

@router.patch('/{id}/suspend', response_model=Entity)
def suspend_entity(id: int, db: Session = Depends(get_db)):
    service = EntityService(db)
    try:
        return service.suspend_entity(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.patch('/{id}/activate', response_model=Entity)
def activate_entity(id: int, db: Session = Depends(get_db)):
    service = EntityService(db)
    try:
        return service.activate_entity(id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
