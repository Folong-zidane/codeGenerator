# Repository pattern implementation for Product
from sqlalchemy.orm import Session
from typing import List, Optional
from models.product import Product

class ProductRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[Product]:
        return self.db.query(Product).all()

    def find_by_id(self, id: int) -> Optional[Product]:
        return self.db.query(Product).filter(Product.id == id).first()

    def save(self, entity: Product) -> Product:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
