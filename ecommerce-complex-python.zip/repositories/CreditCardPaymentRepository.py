# Repository pattern implementation for CreditCardPayment
from sqlalchemy.orm import Session
from typing import List, Optional
from models.creditcardpayment import CreditCardPayment

class CreditCardPaymentRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[CreditCardPayment]:
        return self.db.query(CreditCardPayment).all()

    def find_by_id(self, id: int) -> Optional[CreditCardPayment]:
        return self.db.query(CreditCardPayment).filter(CreditCardPayment.id == id).first()

    def save(self, entity: CreditCardPayment) -> CreditCardPayment:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
