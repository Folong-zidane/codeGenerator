# Repository pattern implementation for OrderItem
from sqlalchemy.orm import Session
from typing import List, Optional
from models.orderitem import OrderItem

class OrderItemRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[OrderItem]:
        return self.db.query(OrderItem).all()

    def find_by_id(self, id: int) -> Optional[OrderItem]:
        return self.db.query(OrderItem).filter(OrderItem.id == id).first()

    def save(self, entity: OrderItem) -> OrderItem:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
