# Repository pattern implementation for PayPalPayment
from sqlalchemy.orm import Session
from typing import List, Optional
from models.paypalpayment import PayPalPayment

class PayPalPaymentRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[PayPalPayment]:
        return self.db.query(PayPalPayment).all()

    def find_by_id(self, id: int) -> Optional[PayPalPayment]:
        return self.db.query(PayPalPayment).filter(PayPalPayment.id == id).first()

    def save(self, entity: PayPalPayment) -> PayPalPayment:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
