# Repository pattern implementation for Payment
from sqlalchemy.orm import Session
from typing import List, Optional
from models.payment import Payment

class PaymentRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[Payment]:
        return self.db.query(Payment).all()

    def find_by_id(self, id: int) -> Optional[Payment]:
        return self.db.query(Payment).filter(Payment.id == id).first()

    def save(self, entity: Payment) -> Payment:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
