# Repository pattern implementation for Review
from sqlalchemy.orm import Session
from typing import List, Optional
from models.review import Review

class ReviewRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[Review]:
        return self.db.query(Review).all()

    def find_by_id(self, id: int) -> Optional[Review]:
        return self.db.query(Review).filter(Review.id == id).first()

    def save(self, entity: Review) -> Review:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
