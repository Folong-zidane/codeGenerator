# Repository pattern implementation for Entity
from sqlalchemy.orm import Session
from typing import List, Optional
from models.entity import Entity

class EntityRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_all(self) -> List[Entity]:
        return self.db.query(Entity).all()

    def find_by_id(self, id: int) -> Optional[Entity]:
        return self.db.query(Entity).filter(Entity.id == id).first()

    def save(self, entity: Entity) -> Entity:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete_by_id(self, id: int) -> bool:
        entity = self.find_by_id(id)
        if entity:
            self.db.delete(entity)
            self.db.commit()
            return True
        return False
