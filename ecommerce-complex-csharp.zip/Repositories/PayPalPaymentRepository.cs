using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public interface IPayPalPaymentRepository
    {
        Task<IEnumerable<PayPalPayment>> GetAllAsync();
        Task<PayPalPayment?> GetByIdAsync(int id);
        Task<PayPalPayment> CreateAsync(PayPalPayment entity);
        Task<PayPalPayment> UpdateAsync(PayPalPayment entity);
        Task DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public class PayPalPaymentRepository : IPayPalPaymentRepository
    {
        private readonly ApplicationDbContext _context;

        public PayPalPaymentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<PayPalPayment>> GetAllAsync()
        {
            return await _context.PayPalPayments.ToListAsync();
        }

        public async Task<PayPalPayment?> GetByIdAsync(int id)
        {
            return await _context.PayPalPayments.FindAsync(id);
        }

        public async Task<PayPalPayment> CreateAsync(PayPalPayment entity)
        {
            entity.CreatedAt = DateTime.UtcNow;
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.PayPalPayments.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<PayPalPayment> UpdateAsync(PayPalPayment entity)
        {
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.PayPalPayments.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.PayPalPayments.AnyAsync(e => e.Id == id);
        }
    }
}
