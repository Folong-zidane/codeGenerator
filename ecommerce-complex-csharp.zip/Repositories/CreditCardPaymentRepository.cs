using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public interface ICreditCardPaymentRepository
    {
        Task<IEnumerable<CreditCardPayment>> GetAllAsync();
        Task<CreditCardPayment?> GetByIdAsync(int id);
        Task<CreditCardPayment> CreateAsync(CreditCardPayment entity);
        Task<CreditCardPayment> UpdateAsync(CreditCardPayment entity);
        Task DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public class CreditCardPaymentRepository : ICreditCardPaymentRepository
    {
        private readonly ApplicationDbContext _context;

        public CreditCardPaymentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CreditCardPayment>> GetAllAsync()
        {
            return await _context.CreditCardPayments.ToListAsync();
        }

        public async Task<CreditCardPayment?> GetByIdAsync(int id)
        {
            return await _context.CreditCardPayments.FindAsync(id);
        }

        public async Task<CreditCardPayment> CreateAsync(CreditCardPayment entity)
        {
            entity.CreatedAt = DateTime.UtcNow;
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.CreditCardPayments.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<CreditCardPayment> UpdateAsync(CreditCardPayment entity)
        {
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.CreditCardPayments.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.CreditCardPayments.AnyAsync(e => e.Id == id);
        }
    }
}
