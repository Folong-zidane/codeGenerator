using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public interface IEntityRepository
    {
        Task<IEnumerable<Entity>> GetAllAsync();
        Task<Entity?> GetByIdAsync(int id);
        Task<Entity> CreateAsync(Entity entity);
        Task<Entity> UpdateAsync(Entity entity);
        Task DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ECommerce.Complex.Repositories
{
    public class EntityRepository : IEntityRepository
    {
        private readonly ApplicationDbContext _context;

        public EntityRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Entity>> GetAllAsync()
        {
            return await _context.Entitys.ToListAsync();
        }

        public async Task<Entity?> GetByIdAsync(int id)
        {
            return await _context.Entitys.FindAsync(id);
        }

        public async Task<Entity> CreateAsync(Entity entity)
        {
            entity.CreatedAt = DateTime.UtcNow;
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.Entitys.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<Entity> UpdateAsync(Entity entity)
        {
            entity.UpdatedAt = DateTime.UtcNow;
            
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.Entitys.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Entitys.AnyAsync(e => e.Id == id);
        }
    }
}
