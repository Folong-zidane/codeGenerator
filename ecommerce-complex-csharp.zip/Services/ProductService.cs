using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product?> GetByIdAsync(int id);
        Task<Product> CreateAsync(Product entity);
        Task<Product> UpdateAsync(int id, Product entity);
        Task DeleteAsync(int id);
        Task<Product> SuspendProductAsync(int id);
        Task<Product> ActivateProductAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repository;

        public ProductService(IProductRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Product?> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<Product> CreateAsync(Product entity)
        {
            // Add business logic and validation here
            ValidateEntity(entity);
            
            return await _repository.CreateAsync(entity);
        }

        public async Task<Product> UpdateAsync(int id, Product entity)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null)
            {
                throw new ArgumentException($"Product with id {id} not found");
            }
            
            // Add business logic and validation here
            ValidateEntity(entity);
            
            // Update properties
            entity.Id = id;
            return await _repository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var exists = await _repository.ExistsAsync(id);
            if (!exists)
            {
                throw new ArgumentException($"Product with id {id} not found");
            }
            
            await _repository.DeleteAsync(id);
        }

        public async Task<Product> SuspendProductAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"Product with id {id} not found");
            }
            
            entity.Suspend();
            return await _repository.UpdateAsync(entity);
        }

        public async Task<Product> ActivateProductAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"Product with id {id} not found");
            }
            
            entity.Activate();
            return await _repository.UpdateAsync(entity);
        }

        private void ValidateEntity(Product entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            
            // Add custom validation logic here
        }
    }
}
