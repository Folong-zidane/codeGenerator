using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public interface ICreditCardPaymentService
    {
        Task<IEnumerable<CreditCardPayment>> GetAllAsync();
        Task<CreditCardPayment?> GetByIdAsync(int id);
        Task<CreditCardPayment> CreateAsync(CreditCardPayment entity);
        Task<CreditCardPayment> UpdateAsync(int id, CreditCardPayment entity);
        Task DeleteAsync(int id);
        Task<CreditCardPayment> SuspendCreditCardPaymentAsync(int id);
        Task<CreditCardPayment> ActivateCreditCardPaymentAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public class CreditCardPaymentService : ICreditCardPaymentService
    {
        private readonly ICreditCardPaymentRepository _repository;

        public CreditCardPaymentService(ICreditCardPaymentRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<CreditCardPayment>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<CreditCardPayment?> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<CreditCardPayment> CreateAsync(CreditCardPayment entity)
        {
            // Add business logic and validation here
            ValidateEntity(entity);
            
            return await _repository.CreateAsync(entity);
        }

        public async Task<CreditCardPayment> UpdateAsync(int id, CreditCardPayment entity)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null)
            {
                throw new ArgumentException($"CreditCardPayment with id {id} not found");
            }
            
            // Add business logic and validation here
            ValidateEntity(entity);
            
            // Update properties
            entity.Id = id;
            return await _repository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var exists = await _repository.ExistsAsync(id);
            if (!exists)
            {
                throw new ArgumentException($"CreditCardPayment with id {id} not found");
            }
            
            await _repository.DeleteAsync(id);
        }

        public async Task<CreditCardPayment> SuspendCreditCardPaymentAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"CreditCardPayment with id {id} not found");
            }
            
            entity.Suspend();
            return await _repository.UpdateAsync(entity);
        }

        public async Task<CreditCardPayment> ActivateCreditCardPaymentAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"CreditCardPayment with id {id} not found");
            }
            
            entity.Activate();
            return await _repository.UpdateAsync(entity);
        }

        private void ValidateEntity(CreditCardPayment entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            
            // Add custom validation logic here
        }
    }
}
