using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public interface IReviewService
    {
        Task<IEnumerable<Review>> GetAllAsync();
        Task<Review?> GetByIdAsync(int id);
        Task<Review> CreateAsync(Review entity);
        Task<Review> UpdateAsync(int id, Review entity);
        Task DeleteAsync(int id);
        Task<Review> SuspendReviewAsync(int id);
        Task<Review> ActivateReviewAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public class ReviewService : IReviewService
    {
        private readonly IReviewRepository _repository;

        public ReviewService(IReviewRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Review>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Review?> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<Review> CreateAsync(Review entity)
        {
            // Add business logic and validation here
            ValidateEntity(entity);
            
            return await _repository.CreateAsync(entity);
        }

        public async Task<Review> UpdateAsync(int id, Review entity)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null)
            {
                throw new ArgumentException($"Review with id {id} not found");
            }
            
            // Add business logic and validation here
            ValidateEntity(entity);
            
            // Update properties
            entity.Id = id;
            return await _repository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var exists = await _repository.ExistsAsync(id);
            if (!exists)
            {
                throw new ArgumentException($"Review with id {id} not found");
            }
            
            await _repository.DeleteAsync(id);
        }

        public async Task<Review> SuspendReviewAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"Review with id {id} not found");
            }
            
            entity.Suspend();
            return await _repository.UpdateAsync(entity);
        }

        public async Task<Review> ActivateReviewAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"Review with id {id} not found");
            }
            
            entity.Activate();
            return await _repository.UpdateAsync(entity);
        }

        private void ValidateEntity(Review entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            
            // Add custom validation logic here
        }
    }
}
