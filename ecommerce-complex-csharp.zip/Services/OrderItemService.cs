using ECommerce.Complex.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public interface IOrderItemService
    {
        Task<IEnumerable<OrderItem>> GetAllAsync();
        Task<OrderItem?> GetByIdAsync(int id);
        Task<OrderItem> CreateAsync(OrderItem entity);
        Task<OrderItem> UpdateAsync(int id, OrderItem entity);
        Task DeleteAsync(int id);
        Task<OrderItem> SuspendOrderItemAsync(int id);
        Task<OrderItem> ActivateOrderItemAsync(int id);
    }
}


using ECommerce.Complex.Models;
using ECommerce.Complex.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Services
{
    public class OrderItemService : IOrderItemService
    {
        private readonly IOrderItemRepository _repository;

        public OrderItemService(IOrderItemRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<OrderItem>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<OrderItem?> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<OrderItem> CreateAsync(OrderItem entity)
        {
            // Add business logic and validation here
            ValidateEntity(entity);
            
            return await _repository.CreateAsync(entity);
        }

        public async Task<OrderItem> UpdateAsync(int id, OrderItem entity)
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing == null)
            {
                throw new ArgumentException($"OrderItem with id {id} not found");
            }
            
            // Add business logic and validation here
            ValidateEntity(entity);
            
            // Update properties
            entity.Id = id;
            return await _repository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var exists = await _repository.ExistsAsync(id);
            if (!exists)
            {
                throw new ArgumentException($"OrderItem with id {id} not found");
            }
            
            await _repository.DeleteAsync(id);
        }

        public async Task<OrderItem> SuspendOrderItemAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"OrderItem with id {id} not found");
            }
            
            entity.Suspend();
            return await _repository.UpdateAsync(entity);
        }

        public async Task<OrderItem> ActivateOrderItemAsync(int id)
        {
            var entity = await _repository.GetByIdAsync(id);
            if (entity == null)
            {
                throw new ArgumentException($"OrderItem with id {id} not found");
            }
            
            entity.Activate();
            return await _repository.UpdateAsync(entity);
        }

        private void ValidateEntity(OrderItem entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            
            // Add custom validation logic here
        }
    }
}
