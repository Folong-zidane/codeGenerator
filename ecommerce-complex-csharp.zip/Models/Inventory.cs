using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("inventorys")]
    public class Inventory
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        public string Product~ products { get; set; }

        public string Void { get; set; }

        public string Void { get; set; }

        public string Product { get; set; }

        public string Quantity) void { get; set; }

        [Column("status")]
        public InventoryStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public void Suspend()
        {
            if (Status != InventoryStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = InventoryStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != InventoryStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = InventoryStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
