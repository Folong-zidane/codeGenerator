using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("orderitems")]
    public class OrderItem
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        public int Quantity { get; set; }

        public string UnitPrice { get; set; }

        public string LineTotal { get; set; }

        public string BigDecimal { get; set; }

        public string Product { get; set; }

        [Column("status")]
        public OrderItemStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public void Suspend()
        {
            if (Status != OrderItemStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = OrderItemStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != OrderItemStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = OrderItemStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
