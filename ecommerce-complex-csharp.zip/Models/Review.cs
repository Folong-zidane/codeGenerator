using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("reviews")]
    public class Review
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        public int Rating { get; set; }

        [Required]
        [StringLength(255)]
        public string Comment { get; set; }

        public string Author { get; set; }

        public int HelpfulCount { get; set; }

        public string Int { get; set; }

        public string Boolean { get; set; }

        [Column("status")]
        public ReviewStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public void Suspend()
        {
            if (Status != ReviewStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = ReviewStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != ReviewStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = ReviewStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
