using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("products")]
    public class Product
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(255)]
        public string Name { get; set; }

        [Required]
        [StringLength(255)]
        public string Description { get; set; }

        public string Price { get; set; }

        public int Quantity { get; set; }

        [Required]
        [StringLength(255)]
        public string Sku { get; set; }

        public string Category { get; set; }

        public string Reviews { get; set; }

        public string Void { get; set; }

        public string Void { get; set; }

        public string Double { get; set; }

        public string Boolean { get; set; }

        [Column("status")]
        public ProductStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public void UpdateStock(int newQuantity)
        {
            if (newQuantity < 0)
            {
                throw new ArgumentException("Stock cannot be negative");
            }
            Stock = newQuantity;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Suspend()
        {
            if (Status != ProductStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = ProductStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != ProductStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = ProductStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
