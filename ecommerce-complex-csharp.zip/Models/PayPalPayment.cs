using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("paypalpayments")]
    public class PayPalPayment
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(255)]
        public string Email { get; set; }

        [Required]
        [StringLength(255)]
        public string TransactionId { get; set; }

        public string Boolean { get; set; }

        public string Boolean { get; set; }

        [Column("status")]
        public PayPalPaymentStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public void Suspend()
        {
            if (Status != PayPalPaymentStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = PayPalPaymentStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != PayPalPaymentStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = PayPalPaymentStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
