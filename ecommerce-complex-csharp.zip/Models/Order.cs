using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

using Complex.Application.Enums;

namespace Complex.Application.Models
{
    [Table("orders")]
    public class Order
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(255)]
        public string OrderNumber { get; set; }

        public string Status { get; set; }

        public string OrderDate { get; set; }

        public string TotalAmount { get; set; }

        [Required]
        [StringLength(255)]
        public string ShippingAddress { get; set; }

        public string BigDecimal { get; set; }

        public string Void { get; set; }

        public string List~OrderItem~ { get; set; }

        public string Boolean { get; set; }

        [Column("status")]
        public OrderStatus Status { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public decimal CalculateTotal(List<Product> products)
        {
            if (products == null || !products.Any())
            {
                throw new ArgumentException("Cannot calculate total: no products");
            }
            var total = products.Sum(p => p.Price);
            Total = total;
            return total;
        }

        public void Suspend()
        {
            if (Status != OrderStatus.ACTIVE)
            {
                throw new InvalidOperationException($"Cannot suspend entity in state: {Status}");
            }
            Status = OrderStatus.SUSPENDED;
            UpdatedAt = DateTime.UtcNow;
        }

        public void Activate()
        {
            if (Status != OrderStatus.SUSPENDED)
            {
                throw new InvalidOperationException($"Cannot activate entity in state: {Status}");
            }
            Status = OrderStatus.ACTIVE;
            UpdatedAt = DateTime.UtcNow;
        }

    }
}
