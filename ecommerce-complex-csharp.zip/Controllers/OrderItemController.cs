using ECommerce.Complex.Models;
using ECommerce.Complex.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemService _service;

        public OrderItemController(IOrderItemService service)
        {
            _service = service;
        }

        /// <summary>
        /// Get all orderitems
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderItem>>> GetAll()
        {
            try
            {
                var entities = await _service.GetAllAsync();
                return Ok(entities);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Get orderitem by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderItem>> GetById(int id)
        {
            try
            {
                var entity = await _service.GetByIdAsync(id);
                if (entity == null)
                {
                    return NotFound(new { error = "OrderItem not found", id });
                }
                return Ok(entity);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Create new orderitem
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<OrderItem>> Create([FromBody] OrderItem entity)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                var created = await _service.CreateAsync(entity);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = "Validation error", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Update orderitem by ID
        /// </summary>
        [HttpPut("{id}")]
        public async Task<ActionResult<OrderItem>> Update(int id, [FromBody] OrderItem entity)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                var updated = await _service.UpdateAsync(id, entity);
                return Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Delete orderitem by ID
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _service.DeleteAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Suspend orderitem by ID
        /// </summary>
        [HttpPatch("{id}/suspend")]
        public async Task<ActionResult<OrderItem>> Suspend(int id)
        {
            try
            {
                var entity = await _service.SuspendOrderItemAsync(id);
                return Ok(entity);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = "Invalid state transition", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Activate orderitem by ID
        /// </summary>
        [HttpPatch("{id}/activate")]
        public async Task<ActionResult<OrderItem>> Activate(int id)
        {
            try
            {
                var entity = await _service.ActivateOrderItemAsync(id);
                return Ok(entity);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = "Invalid state transition", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

    }
}
