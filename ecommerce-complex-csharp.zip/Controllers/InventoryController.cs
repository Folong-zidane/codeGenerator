using ECommerce.Complex.Models;
using ECommerce.Complex.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

using ECommerce.Complex.Enums;

namespace ECommerce.Complex.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryService _service;

        public InventoryController(IInventoryService service)
        {
            _service = service;
        }

        /// <summary>
        /// Get all inventorys
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Inventory>>> GetAll()
        {
            try
            {
                var entities = await _service.GetAllAsync();
                return Ok(entities);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Get inventory by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<Inventory>> GetById(int id)
        {
            try
            {
                var entity = await _service.GetByIdAsync(id);
                if (entity == null)
                {
                    return NotFound(new { error = "Inventory not found", id });
                }
                return Ok(entity);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Create new inventory
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Inventory>> Create([FromBody] Inventory entity)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                var created = await _service.CreateAsync(entity);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = "Validation error", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Update inventory by ID
        /// </summary>
        [HttpPut("{id}")]
        public async Task<ActionResult<Inventory>> Update(int id, [FromBody] Inventory entity)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                var updated = await _service.UpdateAsync(id, entity);
                return Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Delete inventory by ID
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _service.DeleteAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Suspend inventory by ID
        /// </summary>
        [HttpPatch("{id}/suspend")]
        public async Task<ActionResult<Inventory>> Suspend(int id)
        {
            try
            {
                var entity = await _service.SuspendInventoryAsync(id);
                return Ok(entity);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = "Invalid state transition", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

        /// <summary>
        /// Activate inventory by ID
        /// </summary>
        [HttpPatch("{id}/activate")]
        public async Task<ActionResult<Inventory>> Activate(int id)
        {
            try
            {
                var entity = await _service.ActivateInventoryAsync(id);
                return Ok(entity);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { error = "Entity not found", message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = "Invalid state transition", message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Internal server error", message = ex.Message });
            }
        }

    }
}
