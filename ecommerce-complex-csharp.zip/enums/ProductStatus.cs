namespace Complex.Application.Enums
{
    public enum ProductStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
