namespace Complex.Application.Enums
{
    public enum ReviewStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
