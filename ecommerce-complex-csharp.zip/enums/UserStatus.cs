namespace Complex.Application.Enums
{
    public enum UserStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
