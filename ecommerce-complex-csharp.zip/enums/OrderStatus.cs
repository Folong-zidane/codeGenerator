namespace Complex.Application.Enums
{
    public enum OrderStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
