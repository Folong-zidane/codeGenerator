namespace Complex.Application.Enums
{
    public enum PaymentStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
