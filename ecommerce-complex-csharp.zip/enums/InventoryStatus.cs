namespace Complex.Application.Enums
{
    public enum InventoryStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
