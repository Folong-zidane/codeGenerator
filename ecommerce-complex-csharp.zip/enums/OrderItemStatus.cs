namespace Complex.Application.Enums
{
    public enum OrderItemStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
