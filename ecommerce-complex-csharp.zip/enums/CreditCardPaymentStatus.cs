namespace Complex.Application.Enums
{
    public enum CreditCardPaymentStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
