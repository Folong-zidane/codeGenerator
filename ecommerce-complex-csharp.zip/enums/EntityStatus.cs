namespace Complex.Application.Enums
{
    public enum EntityStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
