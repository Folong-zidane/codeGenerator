namespace Complex.Application.Enums
{
    public enum PayPalPaymentStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
