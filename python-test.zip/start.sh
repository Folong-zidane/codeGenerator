#!/bin/bash
echo "🚀 Démarrage Python..."
python3 -m venv venv 2>/dev/null || true
source venv/bin/activate
pip install -r requirements.txt -q
python main.py
