from sqlalchemy.orm import Session
from typing import Optional, List
from uuid import UUID
from entities.Product import Product

class ProductRepository:
    def __init__(self, db: Session):
        self.db = db

    def find_by_id(self, id: UUID) -> Optional[Product]:
        return self.db.query(Product).filter(Product.id == id).first()

    def find_all(self) -> List[Product]:
        return self.db.query(Product).all()

    def save(self, entity: Product) -> Product:
        self.db.add(entity)
        self.db.commit()
        self.db.refresh(entity)
        return entity

    def delete(self, entity: Product):
        self.db.delete(entity)
        self.db.commit()

    def delete_by_id(self, id: UUID):
        entity = self.find_by_id(id)
        if entity:
            self.delete(entity)
