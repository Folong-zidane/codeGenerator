from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from entities.Product import Product
from repositories.ProductRepository import ProductRepository
from services.ProductService import ProductService
from config.database import get_db

router = APIRouter(prefix="/api/product", tags=["Product"])

def get_service(db: Session = Depends(get_db)) -> ProductService:
    repository = ProductRepository(db)
    return ProductService(repository)

@router.post("/")
async def create_product(entity: Product, service: ProductService = Depends(get_service)):
    return service.create(entity)

@router.get("/{id}")
async def get_product(id: UUID, service: ProductService = Depends(get_service)):
    entity = service.find_by_id(id)
    if not entity:
        raise HTTPException(status_code=404, detail="Not found")
    return entity

@router.get("/")
async def get_all_product(service: ProductService = Depends(get_service)) -> List[Product]:
    return service.find_all()

@router.put("/{id}")
async def update_product(id: UUID, entity: Product, service: ProductService = Depends(get_service)):
    entity.id = id
    return service.update(entity)

@router.delete("/{id}")
async def delete_product(id: UUID, service: ProductService = Depends(get_service)):
    service.delete(id)
    return {"message": "Deleted successfully"}
