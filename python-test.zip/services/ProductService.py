from typing import Optional, List
from uuid import UUID
from entities.Product import Product
from repositories.ProductRepository import ProductRepository

class ProductService:
    def __init__(self, repository: ProductRepository):
        self.repository = repository

    def create(self, entity: Product) -> Product:
        return self.repository.save(entity)

    def find_by_id(self, id: UUID) -> Optional[Product]:
        return self.repository.find_by_id(id)

    def find_all(self) -> List[Product]:
        return self.repository.find_all()

    def update(self, entity: Product) -> Product:
        return self.repository.save(entity)

    def delete(self, id: UUID):
        self.repository.delete_by_id(id)
