package com.ecommerce.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
