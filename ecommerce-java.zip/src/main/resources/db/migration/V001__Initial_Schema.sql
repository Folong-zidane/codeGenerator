-- ============================================
-- Flyway Migration: V001__Initial_Schema.sql
-- ============================================
-- Description: Create initial database schema
-- Date: 2025-12-02 03:38:02
-- Version: 1.0.0
-- ============================================

-- Set charset for database compatibility
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET COLLATION_CONNECTION = utf8mb4_unicode_ci;

-- ============================================
-- Table: user (User)
-- ============================================
CREATE TABLE IF NOT EXISTS user (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'Primary Key',
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE' COMMENT 'Entity status (ACTIVE, INACTIVE, SUSPENDED)',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update timestamp',
    version BIGINT NOT NULL DEFAULT 0 COMMENT 'Optimistic locking version'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='User entity table';

CREATE INDEX IF NOT EXISTS idx_user_created_at ON user (created_at) COMMENT 'Index for time-based queries';
CREATE INDEX IF NOT EXISTS idx_user_status ON user (status) COMMENT 'Index for status filtering';

