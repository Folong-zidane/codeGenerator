package com.debug.test.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
