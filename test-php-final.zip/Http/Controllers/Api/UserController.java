<?php

namespace com.test\Http\Controllers\Api;

use com.test\Http\Controllers\Controller;
use com.test\Models\User;
use com.test\Services\UserService;
use com.test\Http\Resources\UserResource;
use com.test\Http\Requests\StoreUserRequest;
use com.test\Http\Requests\UpdateUserRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    protected UserService $service;

    public function __construct(UserService $service)
    {
        $this->service = $service;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        try {
            $perPage = $request->get('per_page', 15);
            $entities = $this->service->getPaginated($perPage);
            
            return UserResource::collection($entities);
        } catch (\Exception $e) {
            Log::error('Error fetching users: ' . $e->getMessage());
            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id): JsonResponse
    {
        try {
            $entity = $this->service->findById($id);
            
            if (!$entity) {
                return response()->json(['error' => 'User not found'], 404);
            }
            
            return response()->json(new UserResource($entity));
        } catch (\Exception $e) {
            Log::error('Error fetching user: ' . $e->getMessage());
            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request): JsonResponse
    {
        try {
            $entity = $this->service->create($request->validated());
            
            return response()->json(new UserResource($entity), 201);
        } catch (\Exception $e) {
            Log::error('Error creating user: ' . $e->getMessage());
            return response()->json(['error' => 'Bad request', 'message' => $e->getMessage()], 400);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, int $id): JsonResponse
    {
        try {
            $entity = $this->service->update($id, $request->validated());
            
            if (!$entity) {
                return response()->json(['error' => 'User not found'], 404);
            }
            
            return response()->json(new UserResource($entity));
        } catch (\InvalidArgumentException $e) {
            return response()->json(['error' => 'Entity not found', 'message' => $e->getMessage()], 404);
        } catch (\Exception $e) {
            Log::error('Error updating user: ' . $e->getMessage());
            return response()->json(['error' => 'Bad request', 'message' => $e->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id): JsonResponse
    {
        try {
            $deleted = $this->service->delete($id);
            
            if (!$deleted) {
                return response()->json(['error' => 'User not found'], 404);
            }
            
            return response()->json(null, 204);
        } catch (\InvalidArgumentException $e) {
            return response()->json(['error' => 'Entity not found', 'message' => $e->getMessage()], 404);
        } catch (\Exception $e) {
            Log::error('Error deleting user: ' . $e->getMessage());
            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    /**
     * Suspend the specified user.
     */
    public function suspend(int $id): JsonResponse
    {
        try {
            $entity = $this->service->suspendUser($id);
            
            return response()->json(new UserResource($entity));
        } catch (\InvalidArgumentException $e) {
            return response()->json(['error' => 'Entity not found', 'message' => $e->getMessage()], 404);
        } catch (\Exception $e) {
            Log::error('Error suspending user: ' . $e->getMessage());
            return response()->json(['error' => 'Invalid state transition', 'message' => $e->getMessage()], 400);
        }
    }

    /**
     * Activate the specified user.
     */
    public function activate(int $id): JsonResponse
    {
        try {
            $entity = $this->service->activateUser($id);
            
            return response()->json(new UserResource($entity));
        } catch (\InvalidArgumentException $e) {
            return response()->json(['error' => 'Entity not found', 'message' => $e->getMessage()], 404);
        } catch (\Exception $e) {
            Log::error('Error activating user: ' . $e->getMessage());
            return response()->json(['error' => 'Invalid state transition', 'message' => $e->getMessage()], 400);
        }
    }

}
