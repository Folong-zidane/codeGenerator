<?php

namespace com.test\Services;

use com.test\Models\User;
use com.test\Repositories\UserRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

use com.test\Enums\UserStatus;

class UserService
{
    protected UserRepositoryInterface $repository;

    public function __construct(UserRepositoryInterface $repository)
    {
        $this->repository = $repository;
    }

    public function getAll(): Collection
    {
        return $this->repository->getAll();
    }

    public function getPaginated(int $perPage = 15): LengthAwarePaginator
    {
        return $this->repository->getPaginated($perPage);
    }

    public function findById(int $id): ?User
    {
        return $this->repository->findById($id);
    }

    public function create(array $data): User
    {
        $this->validateData($data);
        
        try {
            return $this->repository->create($data);
        } catch (\Exception $e) {
            Log::error('Service error creating User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function update(int $id, array $data): ?User
    {
        $entity = $this->repository->findById($id);
        if (!$entity) {
            throw new \InvalidArgumentException('User not found with id: ' . $id);
        }
        
        $this->validateData($data, $id);
        
        try {
            return $this->repository->update($id, $data);
        } catch (\Exception $e) {
            Log::error('Service error updating User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function delete(int $id): bool
    {
        $entity = $this->repository->findById($id);
        if (!$entity) {
            throw new \InvalidArgumentException('User not found with id: ' . $id);
        }
        
        try {
            return $this->repository->delete($id);
        } catch (\Exception $e) {
            Log::error('Service error deleting User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function suspendUser(int $id): ?User
    {
        $entity = $this->repository->findById($id);
        if (!$entity) {
            throw new \InvalidArgumentException('User not found with id: ' . $id);
        }
        
        try {
            $entity->suspend();
            return $entity;
        } catch (\Exception $e) {
            Log::error('Service error suspending User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function activateUser(int $id): ?User
    {
        $entity = $this->repository->findById($id);
        if (!$entity) {
            throw new \InvalidArgumentException('User not found with id: ' . $id);
        }
        
        try {
            $entity->activate();
            return $entity;
        } catch (\Exception $e) {
            Log::error('Service error activating User: ' . $e->getMessage());
            throw $e;
        }
    }

    protected function validateData(array $data, ?int $id = null): void
    {
        $rules = [
            // Add validation rules here
            // 'name' => 'required|string|max:255',
            // 'email' => 'required|email|unique:users,email' . ($id ? ',' . $id : ''),
        ];
        
        $validator = Validator::make($data, $rules);
        
        if ($validator->fails()) {
            throw new ValidationException($validator);
        }
    }
}
