<?php

namespace com.test\Repositories;

use com.test\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;

interface UserRepositoryInterface
{
    public function getAll(): Collection;
    public function getPaginated(int $perPage = 15): LengthAwarePaginator;
    public function findById(int $id): ?User;
    public function create(array $data): User;
    public function update(int $id, array $data): ?User;
    public function delete(int $id): bool;
    public function exists(int $id): bool;
}


<?php

namespace com.test\Repositories;

use com.test\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Log;

class UserRepository implements UserRepositoryInterface
{
    protected User $model;

    public function __construct(User $model)
    {
        $this->model = $model;
    }

    public function getAll(): Collection
    {
        return $this->model->all();
    }

    public function getPaginated(int $perPage = 15): LengthAwarePaginator
    {
        return $this->model->paginate($perPage);
    }

    public function findById(int $id): ?User
    {
        return $this->model->find($id);
    }

    public function create(array $data): User
    {
        try {
            return $this->model->create($data);
        } catch (\Exception $e) {
            Log::error('Error creating User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function update(int $id, array $data): ?User
    {
        try {
            $entity = $this->findById($id);
            if ($entity) {
                $entity->update($data);
                return $entity->fresh();
            }
            return null;
        } catch (\Exception $e) {
            Log::error('Error updating User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function delete(int $id): bool
    {
        try {
            $entity = $this->findById($id);
            if ($entity) {
                return $entity->delete();
            }
            return false;
        } catch (\Exception $e) {
            Log::error('Error deleting User: ' . $e->getMessage());
            throw $e;
        }
    }

    public function exists(int $id): bool
    {
        return $this->model->where('id', $id)->exists();
    }
}
