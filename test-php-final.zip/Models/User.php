<?php

namespace com.test\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use com.test\Enums\UserStatus;

class User extends Model
{
    use HasFactory;

    protected $table = 'users';

    protected $fillable = [
        'username',
        'status',
    ];

    protected $casts = [
        'status' => UserStatus::class,
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function suspend(): void
    {
        if ($this->status !== UserStatus::ACTIVE) {
            throw new \InvalidArgumentException('Cannot suspend entity in state: ' . $this->status->value);
        }
        
        $this->status = UserStatus::SUSPENDED;
        $this->updated_at = Carbon::now();
        $this->save();
    }

    public function activate(): void
    {
        if ($this->status !== UserStatus::SUSPENDED) {
            throw new \InvalidArgumentException('Cannot activate entity in state: ' . $this->status->value);
        }
        
        $this->status = UserStatus::ACTIVE;
        $this->updated_at = Carbon::now();
        $this->save();
    }

}
