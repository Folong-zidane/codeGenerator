// Generated Repository
package com.preslog.repository;

import com.preslog.entity.Utilisateur;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository for {@link Utilisateur}
 * Generated automatically from UML model
 */
public interface UtilisateurRepository extends JpaRepository<Utilisateur, UUID> {
}
