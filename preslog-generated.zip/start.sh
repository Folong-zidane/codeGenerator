#!/bin/bash
echo "🚀 Démarrage Java..."
mvn spring-boot:run
