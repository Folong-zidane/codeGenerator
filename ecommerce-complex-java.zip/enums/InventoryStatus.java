package com.ecommerce.complex.enums;

public enum InventoryStatus {
    ACTIVE,
    SUSPENDED
}
