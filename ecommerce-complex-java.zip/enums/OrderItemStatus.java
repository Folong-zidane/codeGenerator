package com.ecommerce.complex.enums;

public enum OrderItemStatus {
    ACTIVE,
    SUSPENDED
}
