package com.ecommerce.complex.enums;

public enum OrderStatus {
    ACTIVE,
    SUSPENDED
}
