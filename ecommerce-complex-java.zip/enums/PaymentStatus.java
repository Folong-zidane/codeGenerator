package com.ecommerce.complex.enums;

public enum PaymentStatus {
    ACTIVE,
    SUSPENDED
}
