package com.ecommerce.complex.enums;

public enum PayPalPaymentStatus {
    ACTIVE,
    SUSPENDED
}
