package com.ecommerce.complex.enums;

public enum ReviewStatus {
    ACTIVE,
    SUSPENDED
}
