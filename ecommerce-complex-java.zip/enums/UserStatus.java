package com.ecommerce.complex.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
