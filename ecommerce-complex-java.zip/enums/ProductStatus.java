package com.ecommerce.complex.enums;

public enum ProductStatus {
    ACTIVE,
    SUSPENDED
}
