package com.ecommerce.complex.enums;

public enum EntityStatus {
    ACTIVE,
    SUSPENDED
}
