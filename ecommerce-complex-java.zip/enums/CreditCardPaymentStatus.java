package com.ecommerce.complex.enums;

public enum CreditCardPaymentStatus {
    ACTIVE,
    SUSPENDED
}
