namespace com.improved.test.Enums
{
    public enum UserStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
