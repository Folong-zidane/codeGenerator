package com.perf.test.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
