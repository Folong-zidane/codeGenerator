package com.perf.test.enums;

public enum PostStatus {
    ACTIVE,
    SUSPENDED
}
