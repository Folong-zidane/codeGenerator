package com.perf.test.service;

import com.perf.test.entity.Post;
import com.perf.test.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

import com.perf.test.enums.PostStatus;

@Service
@RequiredArgsConstructor
@Transactional
public class PostService {

    private final PostRepository repository;

    public List<Post> findAll() {
        return repository.findAll();
    }

    public Optional<Post> findById(Long id) {
        return repository.findById(id);
    }

    public Post save(Post entity) {
        return repository.save(entity);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    public Post suspendPost(Long id) {
        Post entity = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Post not found with id: " + id));
        entity.suspend();
        return repository.save(entity);
    }

    public Post activatePost(Long id) {
        Post entity = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Post not found with id: " + id));
        entity.activate();
        return repository.save(entity);
    }

}
