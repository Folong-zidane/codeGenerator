# 🚀 Projet order-api - typescript

**Généré le**: 2025-12-02T00:24:25.380520438
**Package**: order-api

## 🚀 Démarrage
```bash
./start.sh    # Linux/macOS
start.bat     # Windows
```

## 🔄 Mise à jour
```bash
./update-project.sh model.mermaid
```

## 📁 Structure
- `src/` - Code généré
- `.backups/` - Sauvegardes automatiques
- `model.mermaid` - Diagramme UML
- `update-project.*` - Scripts de mise à jour

## 🛠️ Personnalisation
Votre code sera préservé lors des mises à jour !

## 📚 Commandes
- `./start.sh` - Démarrer l'application
- `./update-project.sh new-model.mermaid` - Mettre à jour
- `ls .backups/` - Voir les sauvegardes
