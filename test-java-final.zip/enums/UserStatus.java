package com.test.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
