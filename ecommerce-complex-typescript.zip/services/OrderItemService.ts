import { OrderItem } from '../entities/OrderItem';
import { OrderItemRepository, IOrderItemRepository } from '../repositories/OrderItemRepository';

export interface IOrderItemService {
  getAll(): Promise<OrderItem[]>;
  getById(id: number): Promise<OrderItem | null>;
  create(data: Partial<OrderItem>): Promise<OrderItem>;
  update(id: number, data: Partial<OrderItem>): Promise<OrderItem | null>;
  delete(id: number): Promise<void>;
  suspendOrderItem(id: number): Promise<OrderItem | null>;
  activateOrderItem(id: number): Promise<OrderItem | null>;
}

export class OrderItemService implements IOrderItemService {
  private repository: IOrderItemRepository;

  constructor() {
    this.repository = new OrderItemRepository();
  }

  async getAll(): Promise<OrderItem[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<OrderItem | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<OrderItem>): Promise<OrderItem> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<OrderItem>): Promise<OrderItem | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`OrderItem with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`OrderItem with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendOrderItem(id: number): Promise<OrderItem | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`OrderItem with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activateOrderItem(id: number): Promise<OrderItem | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`OrderItem with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<OrderItem>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
