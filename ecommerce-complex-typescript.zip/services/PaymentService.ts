import { Payment } from '../entities/Payment';
import { PaymentRepository, IPaymentRepository } from '../repositories/PaymentRepository';

export interface IPaymentService {
  getAll(): Promise<Payment[]>;
  getById(id: number): Promise<Payment | null>;
  create(data: Partial<Payment>): Promise<Payment>;
  update(id: number, data: Partial<Payment>): Promise<Payment | null>;
  delete(id: number): Promise<void>;
  suspendPayment(id: number): Promise<Payment | null>;
  activatePayment(id: number): Promise<Payment | null>;
}

export class PaymentService implements IPaymentService {
  private repository: IPaymentRepository;

  constructor() {
    this.repository = new PaymentRepository();
  }

  async getAll(): Promise<Payment[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<Payment | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<Payment>): Promise<Payment> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<Payment>): Promise<Payment | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`Payment with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`Payment with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendPayment(id: number): Promise<Payment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Payment with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activatePayment(id: number): Promise<Payment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Payment with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<Payment>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
