import { Inventory } from '../entities/Inventory';
import { InventoryRepository, IInventoryRepository } from '../repositories/InventoryRepository';

export interface IInventoryService {
  getAll(): Promise<Inventory[]>;
  getById(id: number): Promise<Inventory | null>;
  create(data: Partial<Inventory>): Promise<Inventory>;
  update(id: number, data: Partial<Inventory>): Promise<Inventory | null>;
  delete(id: number): Promise<void>;
  suspendInventory(id: number): Promise<Inventory | null>;
  activateInventory(id: number): Promise<Inventory | null>;
}

export class InventoryService implements IInventoryService {
  private repository: IInventoryRepository;

  constructor() {
    this.repository = new InventoryRepository();
  }

  async getAll(): Promise<Inventory[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<Inventory | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<Inventory>): Promise<Inventory> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<Inventory>): Promise<Inventory | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`Inventory with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`Inventory with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendInventory(id: number): Promise<Inventory | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Inventory with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activateInventory(id: number): Promise<Inventory | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Inventory with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<Inventory>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
