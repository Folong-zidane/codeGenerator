import { Order } from '../entities/Order';
import { OrderRepository, IOrderRepository } from '../repositories/OrderRepository';

export interface IOrderService {
  getAll(): Promise<Order[]>;
  getById(id: number): Promise<Order | null>;
  create(data: Partial<Order>): Promise<Order>;
  update(id: number, data: Partial<Order>): Promise<Order | null>;
  delete(id: number): Promise<void>;
  suspendOrder(id: number): Promise<Order | null>;
  activateOrder(id: number): Promise<Order | null>;
}

export class OrderService implements IOrderService {
  private repository: IOrderRepository;

  constructor() {
    this.repository = new OrderRepository();
  }

  async getAll(): Promise<Order[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<Order | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<Order>): Promise<Order> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<Order>): Promise<Order | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendOrder(id: number): Promise<Order | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activateOrder(id: number): Promise<Order | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<Order>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
