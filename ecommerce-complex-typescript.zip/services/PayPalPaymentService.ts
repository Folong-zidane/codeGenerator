import { PayPalPayment } from '../entities/PayPalPayment';
import { PayPalPaymentRepository, IPayPalPaymentRepository } from '../repositories/PayPalPaymentRepository';

export interface IPayPalPaymentService {
  getAll(): Promise<PayPalPayment[]>;
  getById(id: number): Promise<PayPalPayment | null>;
  create(data: Partial<PayPalPayment>): Promise<PayPalPayment>;
  update(id: number, data: Partial<PayPalPayment>): Promise<PayPalPayment | null>;
  delete(id: number): Promise<void>;
  suspendPayPalPayment(id: number): Promise<PayPalPayment | null>;
  activatePayPalPayment(id: number): Promise<PayPalPayment | null>;
}

export class PayPalPaymentService implements IPayPalPaymentService {
  private repository: IPayPalPaymentRepository;

  constructor() {
    this.repository = new PayPalPaymentRepository();
  }

  async getAll(): Promise<PayPalPayment[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<PayPalPayment | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<PayPalPayment>): Promise<PayPalPayment> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<PayPalPayment>): Promise<PayPalPayment | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`PayPalPayment with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`PayPalPayment with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendPayPalPayment(id: number): Promise<PayPalPayment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`PayPalPayment with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activatePayPalPayment(id: number): Promise<PayPalPayment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`PayPalPayment with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<PayPalPayment>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
