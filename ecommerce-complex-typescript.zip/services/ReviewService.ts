import { Review } from '../entities/Review';
import { ReviewRepository, IReviewRepository } from '../repositories/ReviewRepository';

export interface IReviewService {
  getAll(): Promise<Review[]>;
  getById(id: number): Promise<Review | null>;
  create(data: Partial<Review>): Promise<Review>;
  update(id: number, data: Partial<Review>): Promise<Review | null>;
  delete(id: number): Promise<void>;
  suspendReview(id: number): Promise<Review | null>;
  activateReview(id: number): Promise<Review | null>;
}

export class ReviewService implements IReviewService {
  private repository: IReviewRepository;

  constructor() {
    this.repository = new ReviewRepository();
  }

  async getAll(): Promise<Review[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<Review | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<Review>): Promise<Review> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<Review>): Promise<Review | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`Review with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`Review with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendReview(id: number): Promise<Review | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Review with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activateReview(id: number): Promise<Review | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`Review with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<Review>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
