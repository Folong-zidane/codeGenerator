import { CreditCardPayment } from '../entities/CreditCardPayment';
import { CreditCardPaymentRepository, ICreditCardPaymentRepository } from '../repositories/CreditCardPaymentRepository';

export interface ICreditCardPaymentService {
  getAll(): Promise<CreditCardPayment[]>;
  getById(id: number): Promise<CreditCardPayment | null>;
  create(data: Partial<CreditCardPayment>): Promise<CreditCardPayment>;
  update(id: number, data: Partial<CreditCardPayment>): Promise<CreditCardPayment | null>;
  delete(id: number): Promise<void>;
  suspendCreditCardPayment(id: number): Promise<CreditCardPayment | null>;
  activateCreditCardPayment(id: number): Promise<CreditCardPayment | null>;
}

export class CreditCardPaymentService implements ICreditCardPaymentService {
  private repository: ICreditCardPaymentRepository;

  constructor() {
    this.repository = new CreditCardPaymentRepository();
  }

  async getAll(): Promise<CreditCardPayment[]> {
    return await this.repository.findAll();
  }

  async getById(id: number): Promise<CreditCardPayment | null> {
    return await this.repository.findById(id);
  }

  async create(data: Partial<CreditCardPayment>): Promise<CreditCardPayment> {
    this.validateEntity(data);
    return await this.repository.create(data);
  }

  async update(id: number, data: Partial<CreditCardPayment>): Promise<CreditCardPayment | null> {
    const existing = await this.repository.findById(id);
    if (!existing) {
      throw new Error(`CreditCardPayment with id ${id} not found`);
    }
    
    this.validateEntity(data);
    return await this.repository.update(id, data);
  }

  async delete(id: number): Promise<void> {
    const exists = await this.repository.exists(id);
    if (!exists) {
      throw new Error(`CreditCardPayment with id ${id} not found`);
    }
    
    await this.repository.delete(id);
  }

  async suspendCreditCardPayment(id: number): Promise<CreditCardPayment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`CreditCardPayment with id ${id} not found`);
    }
    
    entity.suspend();
    return await this.repository.update(id, entity);
  }

  async activateCreditCardPayment(id: number): Promise<CreditCardPayment | null> {
    const entity = await this.repository.findById(id);
    if (!entity) {
      throw new Error(`CreditCardPayment with id ${id} not found`);
    }
    
    entity.activate();
    return await this.repository.update(id, entity);
  }

  private validateEntity(data: Partial<CreditCardPayment>): void {
    if (!data) {
      throw new Error('Entity data is required');
    }
    // Add custom validation logic here
  }
}
