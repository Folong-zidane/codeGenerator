import { Request, Response } from 'express';
import { PaymentService, IPaymentService } from '../services/PaymentService';

export class PaymentController {
  private service: IPaymentService;

  constructor() {
    this.service = new PaymentService();
  }

  /**
   * Get all payments
   */
  getAll = async (req: Request, res: Response): Promise<void> => {
    try {
      const entities = await this.service.getAll();
      res.json(entities);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Get payment by ID
   */
  getById = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.getById(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Payment not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Create new payment
   */
  create = async (req: Request, res: Response): Promise<void> => {
    try {
      const entity = await this.service.create(req.body);
      res.status(201).json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Update payment by ID
   */
  update = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.update(id, req.body);
      
      if (!entity) {
        res.status(404).json({ error: 'Payment not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Delete payment by ID
   */
  delete = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      await this.service.delete(id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ error: 'Payment not found', message: (error as Error).message });
    }
  };

  /**
   * Suspend payment by ID
   */
  suspend = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.suspendPayment(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Payment not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

  /**
   * Activate payment by ID
   */
  activate = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.activatePayment(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Payment not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

}
