import { Request, Response } from 'express';
import { OrderService, IOrderService } from '../services/OrderService';

export class OrderController {
  private service: IOrderService;

  constructor() {
    this.service = new OrderService();
  }

  /**
   * Get all orders
   */
  getAll = async (req: Request, res: Response): Promise<void> => {
    try {
      const entities = await this.service.getAll();
      res.json(entities);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Get order by ID
   */
  getById = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.getById(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Order not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Create new order
   */
  create = async (req: Request, res: Response): Promise<void> => {
    try {
      const entity = await this.service.create(req.body);
      res.status(201).json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Update order by ID
   */
  update = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.update(id, req.body);
      
      if (!entity) {
        res.status(404).json({ error: 'Order not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Delete order by ID
   */
  delete = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      await this.service.delete(id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ error: 'Order not found', message: (error as Error).message });
    }
  };

  /**
   * Suspend order by ID
   */
  suspend = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.suspendOrder(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Order not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

  /**
   * Activate order by ID
   */
  activate = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.activateOrder(id);
      
      if (!entity) {
        res.status(404).json({ error: 'Order not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

}
