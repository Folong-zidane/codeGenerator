import { Request, Response } from 'express';
import { OrderItemService, IOrderItemService } from '../services/OrderItemService';

export class OrderItemController {
  private service: IOrderItemService;

  constructor() {
    this.service = new OrderItemService();
  }

  /**
   * Get all orderitems
   */
  getAll = async (req: Request, res: Response): Promise<void> => {
    try {
      const entities = await this.service.getAll();
      res.json(entities);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Get orderitem by ID
   */
  getById = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.getById(id);
      
      if (!entity) {
        res.status(404).json({ error: 'OrderItem not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error', message: (error as Error).message });
    }
  };

  /**
   * Create new orderitem
   */
  create = async (req: Request, res: Response): Promise<void> => {
    try {
      const entity = await this.service.create(req.body);
      res.status(201).json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Update orderitem by ID
   */
  update = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.update(id, req.body);
      
      if (!entity) {
        res.status(404).json({ error: 'OrderItem not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Bad request', message: (error as Error).message });
    }
  };

  /**
   * Delete orderitem by ID
   */
  delete = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      await this.service.delete(id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ error: 'OrderItem not found', message: (error as Error).message });
    }
  };

  /**
   * Suspend orderitem by ID
   */
  suspend = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.suspendOrderItem(id);
      
      if (!entity) {
        res.status(404).json({ error: 'OrderItem not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

  /**
   * Activate orderitem by ID
   */
  activate = async (req: Request, res: Response): Promise<void> => {
    try {
      const id = parseInt(req.params.id);
      const entity = await this.service.activateOrderItem(id);
      
      if (!entity) {
        res.status(404).json({ error: 'OrderItem not found', id });
        return;
      }
      
      res.json(entity);
    } catch (error) {
      res.status(400).json({ error: 'Invalid state transition', message: (error as Error).message });
    }
  };

}
