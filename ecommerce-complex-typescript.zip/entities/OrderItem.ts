import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { OrderItemStatus } from '../enums/OrderItemStatus';

@Entity('orderitems')
export class OrderItem {
  @Column()
  quantity: number;

  @Column()
  unitPrice: string;

  @Column()
  lineTotal: string;

  @Column()
  BigDecimal: string;

  @Column()
  Product: string;

  @Column({ type: 'enum', enum: OrderItemStatus })
  status: OrderItemStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== OrderItemStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = OrderItemStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== OrderItemStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = OrderItemStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
