import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ReviewStatus } from '../enums/ReviewStatus';

@Entity('reviews')
export class Review {
  @Column()
  rating: number;

  @Column()
  comment: string;

  @Column()
  author: string;

  @Column()
  helpfulCount: number;

  @Column()
  int: string;

  @Column()
  boolean: string;

  @Column({ type: 'enum', enum: ReviewStatus })
  status: ReviewStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== ReviewStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = ReviewStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== ReviewStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = ReviewStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
