import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { CreditCardPaymentStatus } from '../enums/CreditCardPaymentStatus';

@Entity('creditcardpayments')
export class CreditCardPayment {
  @Column()
  cardNumber: string;

  @Column()
  expiryDate: string;

  @Column()
  cvv: string;

  @Column()
  boolean: string;

  @Column()
  boolean: string;

  @Column({ type: 'enum', enum: CreditCardPaymentStatus })
  status: CreditCardPaymentStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== CreditCardPaymentStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = CreditCardPaymentStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== CreditCardPaymentStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = CreditCardPaymentStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
