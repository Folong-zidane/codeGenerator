import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { PayPalPaymentStatus } from '../enums/PayPalPaymentStatus';

@Entity('paypalpayments')
export class PayPalPayment {
  @Column()
  email: string;

  @Column()
  transactionId: string;

  @Column()
  boolean: string;

  @Column()
  boolean: string;

  @Column({ type: 'enum', enum: PayPalPaymentStatus })
  status: PayPalPaymentStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== PayPalPaymentStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = PayPalPaymentStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== PayPalPaymentStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = PayPalPaymentStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
