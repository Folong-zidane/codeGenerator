import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { OrderStatus } from '../enums/OrderStatus';

@Entity('orders')
export class Order {
  @Column()
  orderNumber: string;

  @Column()
  status: string;

  @Column()
  orderDate: string;

  @Column()
  totalAmount: string;

  @Column()
  shippingAddress: string;

  @Column()
  BigDecimal: string;

  @Column()
  void: string;

  @Column()
  List~OrderItem~: string;

  @Column()
  boolean: string;

  @Column({ type: 'enum', enum: OrderStatus })
  status: OrderStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== OrderStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = OrderStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== OrderStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = OrderStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
