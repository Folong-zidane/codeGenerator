import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { PaymentStatus } from '../enums/PaymentStatus';

@Entity('payments')
export class Payment {
  @Column()
  boolean: string;

  @Column()
  boolean: string;

  @Column()
  PaymentStatus: string;

  @Column({ type: 'enum', enum: PaymentStatus })
  status: PaymentStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== PaymentStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = PaymentStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== PaymentStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = PaymentStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
