import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { InventoryStatus } from '../enums/InventoryStatus';

@Entity('inventorys')
export class Inventory {
  @Column()
  Product~ products: string;

  @Column()
  void: string;

  @Column()
  void: string;

  @Column()
  Product: string;

  @Column()
  quantity) void: string;

  @Column({ type: 'enum', enum: InventoryStatus })
  status: InventoryStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== InventoryStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = InventoryStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== InventoryStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = InventoryStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
