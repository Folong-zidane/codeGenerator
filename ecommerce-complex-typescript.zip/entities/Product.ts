import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ProductStatus } from '../enums/ProductStatus';

@Entity('products')
export class Product {
  @Column()
  name: string;

  @Column()
  description: string;

  @Column()
  price: string;

  @Column()
  quantity: number;

  @Column()
  sku: string;

  @Column()
  category: string;

  @Column()
  reviews: string;

  @Column()
  void: string;

  @Column()
  void: string;

  @Column()
  Double: string;

  @Column()
  boolean: string;

  @Column({ type: 'enum', enum: ProductStatus })
  status: ProductStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  suspend(): void {
    if (this.status !== ProductStatus.ACTIVE) {
      throw new Error(`Cannot suspend entity in state: ${this.status}`);
    }
    this.status = ProductStatus.SUSPENDED;
    this.updatedAt = new Date();
  }

  activate(): void {
    if (this.status !== ProductStatus.SUSPENDED) {
      throw new Error(`Cannot activate entity in state: ${this.status}`);
    }
    this.status = ProductStatus.ACTIVE;
    this.updatedAt = new Date();
  }

}
