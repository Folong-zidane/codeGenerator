export enum ReviewStatus {
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED'
}
