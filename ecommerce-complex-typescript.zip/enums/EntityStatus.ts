export enum EntityStatus {
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED'
}
