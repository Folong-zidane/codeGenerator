import { Repository } from 'typeorm';
import { Inventory } from '../entities/Inventory';
import { AppDataSource } from '../data-source';

export interface IInventoryRepository {
  findAll(): Promise<Inventory[]>;
  findById(id: number): Promise<Inventory | null>;
  create(entity: Partial<Inventory>): Promise<Inventory>;
  update(id: number, entity: Partial<Inventory>): Promise<Inventory | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class InventoryRepository implements IInventoryRepository {
  private repository: Repository<Inventory>;

  constructor() {
    this.repository = AppDataSource.getRepository(Inventory);
  }

  async findAll(): Promise<Inventory[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Inventory | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Inventory>): Promise<Inventory> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Inventory>): Promise<Inventory | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
