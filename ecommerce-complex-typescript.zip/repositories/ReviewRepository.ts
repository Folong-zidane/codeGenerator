import { Repository } from 'typeorm';
import { Review } from '../entities/Review';
import { AppDataSource } from '../data-source';

export interface IReviewRepository {
  findAll(): Promise<Review[]>;
  findById(id: number): Promise<Review | null>;
  create(entity: Partial<Review>): Promise<Review>;
  update(id: number, entity: Partial<Review>): Promise<Review | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class ReviewRepository implements IReviewRepository {
  private repository: Repository<Review>;

  constructor() {
    this.repository = AppDataSource.getRepository(Review);
  }

  async findAll(): Promise<Review[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Review | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Review>): Promise<Review> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Review>): Promise<Review | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
