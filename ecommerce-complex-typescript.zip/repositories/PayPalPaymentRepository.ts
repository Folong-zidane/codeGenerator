import { Repository } from 'typeorm';
import { PayPalPayment } from '../entities/PayPalPayment';
import { AppDataSource } from '../data-source';

export interface IPayPalPaymentRepository {
  findAll(): Promise<PayPalPayment[]>;
  findById(id: number): Promise<PayPalPayment | null>;
  create(entity: Partial<PayPalPayment>): Promise<PayPalPayment>;
  update(id: number, entity: Partial<PayPalPayment>): Promise<PayPalPayment | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class PayPalPaymentRepository implements IPayPalPaymentRepository {
  private repository: Repository<PayPalPayment>;

  constructor() {
    this.repository = AppDataSource.getRepository(PayPalPayment);
  }

  async findAll(): Promise<PayPalPayment[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<PayPalPayment | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<PayPalPayment>): Promise<PayPalPayment> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<PayPalPayment>): Promise<PayPalPayment | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
