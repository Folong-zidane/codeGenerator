import { Repository } from 'typeorm';
import { Entity } from '../entities/Entity';
import { AppDataSource } from '../data-source';

export interface IEntityRepository {
  findAll(): Promise<Entity[]>;
  findById(id: number): Promise<Entity | null>;
  create(entity: Partial<Entity>): Promise<Entity>;
  update(id: number, entity: Partial<Entity>): Promise<Entity | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class EntityRepository implements IEntityRepository {
  private repository: Repository<Entity>;

  constructor() {
    this.repository = AppDataSource.getRepository(Entity);
  }

  async findAll(): Promise<Entity[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Entity | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Entity>): Promise<Entity> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Entity>): Promise<Entity | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
