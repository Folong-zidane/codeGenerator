import { Repository } from 'typeorm';
import { OrderItem } from '../entities/OrderItem';
import { AppDataSource } from '../data-source';

export interface IOrderItemRepository {
  findAll(): Promise<OrderItem[]>;
  findById(id: number): Promise<OrderItem | null>;
  create(entity: Partial<OrderItem>): Promise<OrderItem>;
  update(id: number, entity: Partial<OrderItem>): Promise<OrderItem | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class OrderItemRepository implements IOrderItemRepository {
  private repository: Repository<OrderItem>;

  constructor() {
    this.repository = AppDataSource.getRepository(OrderItem);
  }

  async findAll(): Promise<OrderItem[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<OrderItem | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<OrderItem>): Promise<OrderItem> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<OrderItem>): Promise<OrderItem | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
