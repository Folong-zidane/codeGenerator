import { Repository } from 'typeorm';
import { Payment } from '../entities/Payment';
import { AppDataSource } from '../data-source';

export interface IPaymentRepository {
  findAll(): Promise<Payment[]>;
  findById(id: number): Promise<Payment | null>;
  create(entity: Partial<Payment>): Promise<Payment>;
  update(id: number, entity: Partial<Payment>): Promise<Payment | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class PaymentRepository implements IPaymentRepository {
  private repository: Repository<Payment>;

  constructor() {
    this.repository = AppDataSource.getRepository(Payment);
  }

  async findAll(): Promise<Payment[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Payment | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Payment>): Promise<Payment> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Payment>): Promise<Payment | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
