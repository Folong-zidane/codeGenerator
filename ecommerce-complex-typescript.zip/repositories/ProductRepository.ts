import { Repository } from 'typeorm';
import { Product } from '../entities/Product';
import { AppDataSource } from '../data-source';

export interface IProductRepository {
  findAll(): Promise<Product[]>;
  findById(id: number): Promise<Product | null>;
  create(entity: Partial<Product>): Promise<Product>;
  update(id: number, entity: Partial<Product>): Promise<Product | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class ProductRepository implements IProductRepository {
  private repository: Repository<Product>;

  constructor() {
    this.repository = AppDataSource.getRepository(Product);
  }

  async findAll(): Promise<Product[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Product | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Product>): Promise<Product> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Product>): Promise<Product | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
