import { Repository } from 'typeorm';
import { Order } from '../entities/Order';
import { AppDataSource } from '../data-source';

export interface IOrderRepository {
  findAll(): Promise<Order[]>;
  findById(id: number): Promise<Order | null>;
  create(entity: Partial<Order>): Promise<Order>;
  update(id: number, entity: Partial<Order>): Promise<Order | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class OrderRepository implements IOrderRepository {
  private repository: Repository<Order>;

  constructor() {
    this.repository = AppDataSource.getRepository(Order);
  }

  async findAll(): Promise<Order[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<Order | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<Order>): Promise<Order> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<Order>): Promise<Order | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
