import { Repository } from 'typeorm';
import { CreditCardPayment } from '../entities/CreditCardPayment';
import { AppDataSource } from '../data-source';

export interface ICreditCardPaymentRepository {
  findAll(): Promise<CreditCardPayment[]>;
  findById(id: number): Promise<CreditCardPayment | null>;
  create(entity: Partial<CreditCardPayment>): Promise<CreditCardPayment>;
  update(id: number, entity: Partial<CreditCardPayment>): Promise<CreditCardPayment | null>;
  delete(id: number): Promise<void>;
  exists(id: number): Promise<boolean>;
}

export class CreditCardPaymentRepository implements ICreditCardPaymentRepository {
  private repository: Repository<CreditCardPayment>;

  constructor() {
    this.repository = AppDataSource.getRepository(CreditCardPayment);
  }

  async findAll(): Promise<CreditCardPayment[]> {
    return await this.repository.find();
  }

  async findById(id: number): Promise<CreditCardPayment | null> {
    return await this.repository.findOne({ where: { id } });
  }

  async create(entity: Partial<CreditCardPayment>): Promise<CreditCardPayment> {
    const newEntity = this.repository.create(entity);
    return await this.repository.save(newEntity);
  }

  async update(id: number, entity: Partial<CreditCardPayment>): Promise<CreditCardPayment | null> {
    await this.repository.update(id, entity);
    return await this.findById(id);
  }

  async delete(id: number): Promise<void> {
    await this.repository.delete(id);
  }

  async exists(id: number): Promise<boolean> {
    const count = await this.repository.count({ where: { id } });
    return count > 0;
  }
}
