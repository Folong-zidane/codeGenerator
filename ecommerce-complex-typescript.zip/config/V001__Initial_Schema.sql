import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { Entity } from './entities/Entity';
import { User } from './entities/User';
import { Order } from './entities/Order';
import { Product } from './entities/Product';
import { OrderItem } from './entities/OrderItem';
import { Review } from './entities/Review';
import { Payment } from './entities/Payment';
import { CreditCardPayment } from './entities/CreditCardPayment';
import { PayPalPayment } from './entities/PayPalPayment';
import { Inventory } from './entities/Inventory';

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  username: process.env.DB_USERNAME || 'postgres',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'ecommerce_complex',
  synchronize: process.env.NODE_ENV === 'development',
  logging: process.env.NODE_ENV === 'development',
  entities: [Entity, User, Order, Product, OrderItem, Review, Payment, CreditCardPayment, PayPalPayment, Inventory],
  migrations: ['src/migrations/*.ts'],
  subscribers: ['src/subscribers/*.ts'],
});


import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { AppDataSource } from './data-source';
import { setupRoutes } from './routes';

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
setupRoutes(app);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
AppDataSource.initialize()
  .then(() => {
    console.log('📊 Database connected successfully');
    
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📖 API documentation: http://localhost:${PORT}/api`);
    });
  })
  .catch((error) => {
    console.error('❌ Database connection failed:', error);
    process.exit(1);
  });

export default app;


import { Express, Router } from 'express';
import { EntityController } from './controllers/EntityController';
import { UserController } from './controllers/UserController';
import { OrderController } from './controllers/OrderController';
import { ProductController } from './controllers/ProductController';
import { OrderItemController } from './controllers/OrderItemController';
import { ReviewController } from './controllers/ReviewController';
import { PaymentController } from './controllers/PaymentController';
import { CreditCardPaymentController } from './controllers/CreditCardPaymentController';
import { PayPalPaymentController } from './controllers/PayPalPaymentController';
import { InventoryController } from './controllers/InventoryController';

export function setupRoutes(app: Express): void {
  const apiRouter = Router();

  // Entity routes
  const entityController = new EntityController();
  const entityRouter = Router();
  entityRouter.get('/', entityController.getAll);
  entityRouter.get('/:id', entityController.getById);
  entityRouter.post('/', entityController.create);
  entityRouter.put('/:id', entityController.update);
  entityRouter.delete('/:id', entityController.delete);
  entityRouter.patch('/:id/suspend', entityController.suspend);
  entityRouter.patch('/:id/activate', entityController.activate);
  apiRouter.use('/entitys', entityRouter);

  // User routes
  const userController = new UserController();
  const userRouter = Router();
  userRouter.get('/', userController.getAll);
  userRouter.get('/:id', userController.getById);
  userRouter.post('/', userController.create);
  userRouter.put('/:id', userController.update);
  userRouter.delete('/:id', userController.delete);
  userRouter.patch('/:id/suspend', userController.suspend);
  userRouter.patch('/:id/activate', userController.activate);
  apiRouter.use('/users', userRouter);

  // Order routes
  const orderController = new OrderController();
  const orderRouter = Router();
  orderRouter.get('/', orderController.getAll);
  orderRouter.get('/:id', orderController.getById);
  orderRouter.post('/', orderController.create);
  orderRouter.put('/:id', orderController.update);
  orderRouter.delete('/:id', orderController.delete);
  orderRouter.patch('/:id/suspend', orderController.suspend);
  orderRouter.patch('/:id/activate', orderController.activate);
  apiRouter.use('/orders', orderRouter);

  // Product routes
  const productController = new ProductController();
  const productRouter = Router();
  productRouter.get('/', productController.getAll);
  productRouter.get('/:id', productController.getById);
  productRouter.post('/', productController.create);
  productRouter.put('/:id', productController.update);
  productRouter.delete('/:id', productController.delete);
  productRouter.patch('/:id/suspend', productController.suspend);
  productRouter.patch('/:id/activate', productController.activate);
  apiRouter.use('/products', productRouter);

  // OrderItem routes
  const orderitemController = new OrderItemController();
  const orderitemRouter = Router();
  orderitemRouter.get('/', orderitemController.getAll);
  orderitemRouter.get('/:id', orderitemController.getById);
  orderitemRouter.post('/', orderitemController.create);
  orderitemRouter.put('/:id', orderitemController.update);
  orderitemRouter.delete('/:id', orderitemController.delete);
  orderitemRouter.patch('/:id/suspend', orderitemController.suspend);
  orderitemRouter.patch('/:id/activate', orderitemController.activate);
  apiRouter.use('/orderitems', orderitemRouter);

  // Review routes
  const reviewController = new ReviewController();
  const reviewRouter = Router();
  reviewRouter.get('/', reviewController.getAll);
  reviewRouter.get('/:id', reviewController.getById);
  reviewRouter.post('/', reviewController.create);
  reviewRouter.put('/:id', reviewController.update);
  reviewRouter.delete('/:id', reviewController.delete);
  reviewRouter.patch('/:id/suspend', reviewController.suspend);
  reviewRouter.patch('/:id/activate', reviewController.activate);
  apiRouter.use('/reviews', reviewRouter);

  // Payment routes
  const paymentController = new PaymentController();
  const paymentRouter = Router();
  paymentRouter.get('/', paymentController.getAll);
  paymentRouter.get('/:id', paymentController.getById);
  paymentRouter.post('/', paymentController.create);
  paymentRouter.put('/:id', paymentController.update);
  paymentRouter.delete('/:id', paymentController.delete);
  paymentRouter.patch('/:id/suspend', paymentController.suspend);
  paymentRouter.patch('/:id/activate', paymentController.activate);
  apiRouter.use('/payments', paymentRouter);

  // CreditCardPayment routes
  const creditcardpaymentController = new CreditCardPaymentController();
  const creditcardpaymentRouter = Router();
  creditcardpaymentRouter.get('/', creditcardpaymentController.getAll);
  creditcardpaymentRouter.get('/:id', creditcardpaymentController.getById);
  creditcardpaymentRouter.post('/', creditcardpaymentController.create);
  creditcardpaymentRouter.put('/:id', creditcardpaymentController.update);
  creditcardpaymentRouter.delete('/:id', creditcardpaymentController.delete);
  creditcardpaymentRouter.patch('/:id/suspend', creditcardpaymentController.suspend);
  creditcardpaymentRouter.patch('/:id/activate', creditcardpaymentController.activate);
  apiRouter.use('/creditcardpayments', creditcardpaymentRouter);

  // PayPalPayment routes
  const paypalpaymentController = new PayPalPaymentController();
  const paypalpaymentRouter = Router();
  paypalpaymentRouter.get('/', paypalpaymentController.getAll);
  paypalpaymentRouter.get('/:id', paypalpaymentController.getById);
  paypalpaymentRouter.post('/', paypalpaymentController.create);
  paypalpaymentRouter.put('/:id', paypalpaymentController.update);
  paypalpaymentRouter.delete('/:id', paypalpaymentController.delete);
  paypalpaymentRouter.patch('/:id/suspend', paypalpaymentController.suspend);
  paypalpaymentRouter.patch('/:id/activate', paypalpaymentController.activate);
  apiRouter.use('/paypalpayments', paypalpaymentRouter);

  // Inventory routes
  const inventoryController = new InventoryController();
  const inventoryRouter = Router();
  inventoryRouter.get('/', inventoryController.getAll);
  inventoryRouter.get('/:id', inventoryController.getById);
  inventoryRouter.post('/', inventoryController.create);
  inventoryRouter.put('/:id', inventoryController.update);
  inventoryRouter.delete('/:id', inventoryController.delete);
  inventoryRouter.patch('/:id/suspend', inventoryController.suspend);
  inventoryRouter.patch('/:id/activate', inventoryController.activate);
  apiRouter.use('/inventorys', inventoryRouter);

  app.use('/api', apiRouter);
}
