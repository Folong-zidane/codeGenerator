package com.test.fixed.enums;

public enum ProductStatus {
    ACTIVE,
    SUSPENDED
}
