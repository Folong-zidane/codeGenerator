#!/bin/bash
echo "🚀 Démarrage C#..."
dotnet run
