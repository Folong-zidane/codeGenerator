using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CustomerApi.Entities;
using CustomerApi.Repositories;

namespace CustomerApi.Services
{
    public interface ICustomerService
    {
        Task<Customer> CreateAsync(Customer entity);
        Task<Customer?> GetByIdAsync(Guid id);
        Task<IEnumerable<Customer>> GetAllAsync();
        Task<Customer> UpdateAsync(Customer entity);
        Task DeleteAsync(Guid id);
    }

    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _repository;

        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }

        public async Task<Customer> CreateAsync(Customer entity)
        {
            return await _repository.CreateAsync(entity);
        }

        public async Task<Customer?> GetByIdAsync(Guid id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Customer>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Customer> UpdateAsync(Customer entity)
        {
            return await _repository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
