#!/bin/bash
echo "🚀 Démarrage TypeScript..."
npm install -q
npm run dev
