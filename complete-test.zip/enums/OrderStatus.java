package com.test.complete.enums;

public enum OrderStatus {
    ACTIVE,
    SUSPENDED
}
