namespace com.test.Enums
{
    public enum UserStatus
    {
        ACTIVE,
        SUSPENDED
    }
}
