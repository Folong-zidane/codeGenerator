<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy as Group;

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../src/Config/Database.php';

$app = AppFactory::create();

// Add error middleware
$app->addErrorMiddleware(true, true, true);

// Add body parsing middleware
$app->addBodyParsingMiddleware();

// Routes
$app->get('/', function (Request $request, Response $response) {
    $data = ['message' => 'Generated PHP API is running'];
    $response->getBody()->write(json_encode($data));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->group('/api/invoice', function (Group $group) {
    $group->get('', \App\Controllers\InvoiceController::class . ':getAll');
    $group->get('/{id}', \App\Controllers\InvoiceController::class . ':getById');
    $group->post('', \App\Controllers\InvoiceController::class . ':create');
    $group->put('/{id}', \App\Controllers\InvoiceController::class . ':update');
    $group->delete('/{id}', \App\Controllers\InvoiceController::class . ':delete');
});



$app->run();
