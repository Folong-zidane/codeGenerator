#!/bin/bash
echo "🚀 Démarrage PHP..."
composer install -q
php -S localhost:8080 index.php
