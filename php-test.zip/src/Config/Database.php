<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$capsule = new Capsule;

$capsule->addConnection([
    'driver' => 'sqlite',
    'database' => __DIR__ . '/../../database.sqlite',
    'prefix' => '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

// Create database file if it doesn't exist
$dbPath = __DIR__ . '/../../database.sqlite';
if (!file_exists($dbPath)) {
    touch($dbPath);
}
