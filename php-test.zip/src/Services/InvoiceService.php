<?php

namespace App\Services;

use App\Repositories\InvoiceRepository;
use App\Models\Invoice;

class InvoiceService
{
    private InvoiceRepository $repository;

    public function __construct()
    {
        $this->repository = new InvoiceRepository();
    }

    public function create(array $data): Invoice
    {
        return $this->repository->create($data);
    }

    public function findById(string $id): ?Invoice
    {
        return $this->repository->findById($id);
    }

    public function findAll(): array
    {
        return $this->repository->findAll();
    }

    public function update(string $id, array $data): ?Invoice
    {
        return $this->repository->update($id, $data);
    }

    public function delete(string $id): bool
    {
        return $this->repository->delete($id);
    }
}
