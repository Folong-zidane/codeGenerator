<?php

namespace App\Repositories;

use App\Models\Invoice;

class InvoiceRepository
{
    public function findById(string $id): ?Invoice
    {
        return Invoice::find($id);
    }

    public function findAll(): array
    {
        return Invoice::all()->toArray();
    }

    public function create(array $data): Invoice
    {
        return Invoice::create($data);
    }

    public function update(string $id, array $data): ?Invoice
    {
        $entity = Invoice::find($id);
        if ($entity) {
            $entity->update($data);
            return $entity;
        }
        return null;
    }

    public function delete(string $id): bool
    {
        $entity = Invoice::find($id);
        if ($entity) {
            return $entity->delete();
        }
        return false;
    }
}
