<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Uuid;

class Invoice extends Model
{
    protected $table = 'invoice';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'number',
        'amount',
    ];

    protected $casts = [
        'id' => 'string',
        'id' => 'string',
        'number' => 'string',
        'amount' => 'float',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = Uuid::uuid4()->toString();
            }
        });
    }
}
