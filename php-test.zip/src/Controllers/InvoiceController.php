<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Services\InvoiceService;

class InvoiceController
{
    private InvoiceService $service;

    public function __construct()
    {
        $this->service = new InvoiceService();
    }

    public function getAll(Request $request, Response $response): Response
    {
        try {
            $entities = $this->service->findAll();
            $response->getBody()->write(json_encode($entities));
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function getById(Request $request, Response $response, array $args): Response
    {
        try {
            $entity = $this->service->findById($args['id']);
            if (!$entity) {
                $response->getBody()->write(json_encode(['error' => 'Not found']));
                return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
            }
            $response->getBody()->write(json_encode($entity));
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function create(Request $request, Response $response): Response
    {
        try {
            $data = $request->getParsedBody();
            $entity = $this->service->create($data);
            $response->getBody()->write(json_encode($entity));
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function update(Request $request, Response $response, array $args): Response
    {
        try {
            $data = $request->getParsedBody();
            $entity = $this->service->update($args['id'], $data);
            if (!$entity) {
                $response->getBody()->write(json_encode(['error' => 'Not found']));
                return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
            }
            $response->getBody()->write(json_encode($entity));
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function delete(Request $request, Response $response, array $args): Response
    {
        try {
            $deleted = $this->service->delete($args['id']);
            if (!$deleted) {
                $response->getBody()->write(json_encode(['error' => 'Not found']));
                return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
            }
            return $response->withStatus(204);
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }
}
