package com.improved.test.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
