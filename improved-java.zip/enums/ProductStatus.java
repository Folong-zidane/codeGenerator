package com.improved.test.enums;

public enum ProductStatus {
    ACTIVE,
    SUSPENDED
}
